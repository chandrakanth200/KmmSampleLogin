package com.example.kmmsamplelogin

expect class Platform() {
    val platform: String
}