package com.example.kmmsamplelogin

class Greeting {
    fun greeting(): String {
        return "Hello, ${Platform().platform}!"
    }
}